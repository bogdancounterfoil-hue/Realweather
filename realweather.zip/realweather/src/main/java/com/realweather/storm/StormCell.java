package com.realweather.storm;

import net.minecraft.network.FriendlyByteBuf;

/**
 * Одна штормова клітина: кругла область, що дрейфує з вітром.
 * Інтенсивність залежить від віку (наростає, тримається, згасає) і від відстані до центру.
 * Клас спільний для сервера й клієнта, тому клієнт може сам екстраполювати рух між пакетами.
 */
public final class StormCell {
	public double x;
	public double z;
	public final double vx;
	public final double vz;
	public final float radius;
	public final float peak;
	public final int lifetime;
	public int age;

	public StormCell(double x, double z, double vx, double vz, float radius, float peak, int lifetime, int age) {
		this.x = x;
		this.z = z;
		this.vx = vx;
		this.vz = vz;
		this.radius = radius;
		this.peak = peak;
		this.lifetime = lifetime;
		this.age = age;
	}

	/** Один тік серверної симуляції. */
	public void tick() {
		x += vx;
		z += vz;
		age++;
	}

	public boolean isDead() {
		return age >= lifetime;
	}

	/**
	 * Інтенсивність дощу (0..1) у точці. {@code extraTicks} — скільки тіків минуло
	 * від моменту, коли клітина мала такі x, z і age (потрібно клієнту для плавності).
	 */
	public float intensityAt(double px, double pz, float extraTicks) {
		double dx = px - (x + vx * extraTicks);
		double dz = pz - (z + vz * extraTicks);
		double distSq = dx * dx + dz * dz;
		double r = radius;
		if (distSq >= r * r) {
			return 0f;
		}
		float envelope = envelope((age + extraTicks) / (float) lifetime);
		if (envelope <= 0f) {
			return 0f;
		}
		float d = (float) (Math.sqrt(distSq) / r);
		// У ядрі (до 40% радіуса) повна сила, далі плавно до нуля на краю.
		float falloff = 1f - smoothstep(0.4f, 1f, d);
		return peak * envelope * falloff;
	}

	/** Життєвий цикл: швидке наростання, плато, повільне згасання. */
	public static float envelope(float t) {
		if (t <= 0f || t >= 1f) {
			return 0f;
		}
		if (t < 0.25f) {
			return smoothstep(0f, 0.25f, t);
		}
		if (t > 0.7f) {
			return 1f - smoothstep(0.7f, 1f, t);
		}
		return 1f;
	}

	public static float smoothstep(float edge0, float edge1, float v) {
		float t = Math.max(0f, Math.min(1f, (v - edge0) / (edge1 - edge0)));
		return t * t * (3f - 2f * t);
	}

	public void write(FriendlyByteBuf buf) {
		buf.writeDouble(x);
		buf.writeDouble(z);
		buf.writeFloat((float) vx);
		buf.writeFloat((float) vz);
		buf.writeFloat(radius);
		buf.writeFloat(peak);
		buf.writeVarInt(lifetime);
		buf.writeVarInt(age);
	}

	public static StormCell read(FriendlyByteBuf buf) {
		double x = buf.readDouble();
		double z = buf.readDouble();
		double vx = buf.readFloat();
		double vz = buf.readFloat();
		float radius = buf.readFloat();
		float peak = buf.readFloat();
		int lifetime = buf.readVarInt();
		int age = buf.readVarInt();
		return new StormCell(x, z, vx, vz, radius, peak, lifetime, age);
	}
}

package com.realweather.storm;

import com.realweather.RealWeatherConfig;
import com.realweather.network.StormSyncPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Серверна симуляція штормових клітин для Верхнього світу.
 * Це кілька легких об'єктів: ніяких перерахунків світу чи чанків, тому майже безкоштовно.
 */
public final class StormManager {
	private static final StormManager INSTANCE = new StormManager();

	private final List<StormCell> cells = new ArrayList<>();
	private double windAngle = Double.NaN;
	private boolean dirty = true;

	public static StormManager get() {
		return INSTANCE;
	}

	public List<StormCell> cells() {
		return Collections.unmodifiableList(cells);
	}

	public void reset() {
		cells.clear();
		windAngle = Double.NaN;
		dirty = true;
	}

	public void clear() {
		cells.clear();
		dirty = true;
	}

	public void tick(ServerLevel level) {
		RealWeatherConfig cfg = RealWeatherConfig.get();
		RandomSource random = level.getRandom();

		if (Double.isNaN(windAngle)) {
			windAngle = random.nextDouble() * Math.PI * 2.0;
		}
		// Напрям вітру повільно «блукає».
		windAngle += (random.nextDouble() - 0.5) * 0.002;

		if (cfg.disableVanillaWeather && (level.isRaining() || level.isThundering())) {
			level.setWeatherParameters(24000, 0, false, false);
		}

		// Рух і старіння клітин.
		for (int i = cells.size() - 1; i >= 0; i--) {
			StormCell cell = cells.get(i);
			cell.tick();
			if (cell.isDead()) {
				cells.remove(i);
				dirty = true;
			}
		}

		// Поява нових клітин.
		if (cells.size() < cfg.maxCells && random.nextInt(cfg.spawnIntervalTicks) == 0) {
			List<ServerPlayer> players = level.players();
			if (!players.isEmpty()) {
				ServerPlayer target = players.get(random.nextInt(players.size()));
				spawnTowards(random, cfg, target.getX(), target.getZ());
			}
		}

		// Синхронізація з клієнтами.
		if (dirty || level.getGameTime() % cfg.syncIntervalTicks == 0) {
			sync(level, cfg);
			dirty = false;
		}
	}

	/** Створює клітину «проти вітру» від точки так, щоб вона пройшла приблизно над нею. */
	private void spawnTowards(RandomSource random, RealWeatherConfig cfg, double targetX, double targetZ) {
		int lifetime = cfg.minLifetimeTicks + random.nextInt(cfg.maxLifetimeTicks - cfg.minLifetimeTicks + 1);
		float radius = cfg.minRadius + random.nextInt(cfg.maxRadius - cfg.minRadius + 1);
		float peak = (float) (cfg.minIntensity + random.nextDouble() * (cfg.maxIntensity - cfg.minIntensity));

		double angle = windAngle + (random.nextDouble() - 0.5) * 0.4;
		double speed = cfg.windSpeed * (0.7 + random.nextDouble() * 0.6);
		double vx = Math.cos(angle) * speed;
		double vz = Math.sin(angle) * speed;

		// Центр шторму має опинитися біля цілі приблизно в середині життя.
		double offsetX = (random.nextDouble() - 0.5) * 2.0 * radius * 0.8;
		double offsetZ = (random.nextDouble() - 0.5) * 2.0 * radius * 0.8;
		double startX = targetX + offsetX - vx * lifetime * 0.5;
		double startZ = targetZ + offsetZ - vz * lifetime * 0.5;

		cells.add(new StormCell(startX, startZ, vx, vz, radius, peak, lifetime, 0));
		dirty = true;
	}

	/** Створює клітину прямо над заданою точкою (для команди /storm spawn). */
	public void spawnAt(RandomSource random, double x, double z, float radius, float peak, int lifetime) {
		RealWeatherConfig cfg = RealWeatherConfig.get();
		if (Double.isNaN(windAngle)) {
			windAngle = random.nextDouble() * Math.PI * 2.0;
		}
		double speed = cfg.windSpeed * (0.7 + random.nextDouble() * 0.6);
		double vx = Math.cos(windAngle) * speed;
		double vz = Math.sin(windAngle) * speed;
		// Починаємо з віку, коли клітина вже в повній силі (25% життя).
		cells.add(new StormCell(x, z, vx, vz, radius, peak, lifetime, (int) (lifetime * 0.25)));
		dirty = true;
	}

	private void sync(ServerLevel level, RealWeatherConfig cfg) {
		double maxDist = cfg.syncRadius;
		for (ServerPlayer player : level.players()) {
			List<StormCell> nearby = new ArrayList<>();
			for (StormCell cell : cells) {
				double dx = cell.x - player.getX();
				double dz = cell.z - player.getZ();
				double reach = maxDist + cell.radius;
				if (dx * dx + dz * dz <= reach * reach) {
					nearby.add(cell);
				}
			}
			ServerPlayNetworking.send(player, new StormSyncPayload(nearby));
		}
	}
}

package com.realweather.network;

import com.realweather.RealWeatherMod;
import com.realweather.storm.StormCell;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.ArrayList;
import java.util.List;

/** Пакет сервер -> клієнт: усі клітини в радіусі синхронізації навколо гравця. */
public record StormSyncPayload(List<StormCell> cells) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<StormSyncPayload> TYPE =
			new CustomPacketPayload.Type<>(RealWeatherMod.id("storm_sync"));

	public static final StreamCodec<FriendlyByteBuf, StormSyncPayload> CODEC =
			CustomPacketPayload.codec(StormSyncPayload::write, StormSyncPayload::read);

	private void write(FriendlyByteBuf buf) {
		buf.writeVarInt(cells.size());
		for (StormCell cell : cells) {
			cell.write(buf);
		}
	}

	private static StormSyncPayload read(FriendlyByteBuf buf) {
		int count = buf.readVarInt();
		List<StormCell> cells = new ArrayList<>(count);
		for (int i = 0; i < count; i++) {
			cells.add(StormCell.read(buf));
		}
		return new StormSyncPayload(cells);
	}

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}

package com.realweather;

import com.realweather.command.StormCommand;
import com.realweather.network.StormSyncPayload;
import com.realweather.storm.StormManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RealWeatherMod implements ModInitializer {
	public static final String MOD_ID = "realweather";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		RealWeatherConfig.load();

		// Пакет сервер -> клієнт зі списком штормових клітин поруч із гравцем.
		PayloadTypeRegistry.playS2C().register(StormSyncPayload.TYPE, StormSyncPayload.CODEC);

		// Шторми живуть тільки в Верхньому світі.
		ServerTickEvents.END_WORLD_TICK.register(level -> {
			if (level.dimension() == Level.OVERWORLD) {
				StormManager.get().tick(level);
			}
		});

		// Після закриття світу забуваємо клітини (важливо для одиночної гри).
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> StormManager.get().reset());

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				StormCommand.register(dispatcher));

		LOGGER.info("Real Weather: основа штормових клітин завантажена");
	}

	public static ResourceLocation id(String path) {
		return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
	}
}

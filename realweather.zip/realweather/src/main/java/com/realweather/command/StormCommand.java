package com.realweather.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.realweather.storm.StormCell;
import com.realweather.storm.StormManager;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

/**
 * /storm spawn [радіус] [інтенсивність] — шторм над вами
 * /storm clear                          — прибрати всі клітини
 * /storm info                           — список клітин
 */
public final class StormCommand {
	private StormCommand() {
	}

	public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
		dispatcher.register(Commands.literal("storm")
				.requires(source -> source.hasPermission(2))
				.then(Commands.literal("spawn")
						.executes(ctx -> spawn(ctx, 250, 1.0f))
						.then(Commands.argument("radius", IntegerArgumentType.integer(30, 2000))
								.executes(ctx -> spawn(ctx, IntegerArgumentType.getInteger(ctx, "radius"), 1.0f))
								.then(Commands.argument("intensity", FloatArgumentType.floatArg(0.1f, 1.0f))
										.executes(ctx -> spawn(ctx,
												IntegerArgumentType.getInteger(ctx, "radius"),
												FloatArgumentType.getFloat(ctx, "intensity"))))))
				.then(Commands.literal("clear").executes(StormCommand::clear))
				.then(Commands.literal("info").executes(StormCommand::info)));
	}

	private static int spawn(CommandContext<CommandSourceStack> ctx, int radius, float intensity) {
		CommandSourceStack source = ctx.getSource();
		Vec3 pos = source.getPosition();
		StormManager.get().spawnAt(source.getLevel().getRandom(), pos.x, pos.z, radius, intensity, 12000);
		source.sendSuccess(() -> Component.literal(
				"Шторм створено над вами: радіус " + radius + ", інтенсивність " + intensity), true);
		return 1;
	}

	private static int clear(CommandContext<CommandSourceStack> ctx) {
		StormManager.get().clear();
		ctx.getSource().sendSuccess(() -> Component.literal("Усі штормові клітини прибрано"), true);
		return 1;
	}

	private static int info(CommandContext<CommandSourceStack> ctx) {
		CommandSourceStack source = ctx.getSource();
		var cells = StormManager.get().cells();
		if (cells.isEmpty()) {
			source.sendSuccess(() -> Component.literal("Штормових клітин немає"), false);
			return 0;
		}
		Vec3 pos = source.getPosition();
		source.sendSuccess(() -> Component.literal("Штормових клітин: " + cells.size()), false);
		for (StormCell cell : cells) {
			double dist = Math.hypot(cell.x - pos.x, cell.z - pos.z);
			int percent = Math.round(100f * cell.age / cell.lifetime);
			source.sendSuccess(() -> Component.literal(String.format(
					"  x=%.0f z=%.0f, радіус %.0f, сила %.2f, вік %d%%, до вас %.0f блоків",
					cell.x, cell.z, cell.radius, cell.peak, percent, dist)), false);
		}
		return cells.size();
	}
}

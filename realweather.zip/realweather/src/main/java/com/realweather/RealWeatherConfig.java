package com.realweather;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Налаштування мода. Файл: config/realweather.json (створюється автоматично).
 * Усі значення обмежуються в {@link #sanitize()}, щоб помилка в конфігу не вбила гру.
 */
public class RealWeatherConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static RealWeatherConfig instance = new RealWeatherConfig();

	/** Вимкнути ванільну глобальну погоду (інакше дощ піде всюди одночасно). */
	public boolean disableVanillaWeather = true;

	/** Максимальна кількість живих клітин у світі. */
	public int maxCells = 24;

	/** У середньому раз на стільки тіків з'являється нова клітина (20 тіків = 1 секунда). */
	public int spawnIntervalTicks = 4800;

	/** Радіус клітини в блоках. */
	public int minRadius = 150;
	public int maxRadius = 400;

	/** Тривалість життя клітини в тіках. */
	public int minLifetimeTicks = 6000;
	public int maxLifetimeTicks = 18000;

	/** Швидкість вітру в блоках за тік (0.12 = приблизно 2.4 блока за секунду). */
	public double windSpeed = 0.12;

	/** Найбільша інтенсивність нової клітини (0.3 – 1.0). */
	public double minIntensity = 0.55;
	public double maxIntensity = 1.0;

	/** Як часто сервер надсилає дані клієнту (у тіках). Між пакетами клієнт екстраполює рух сам. */
	public int syncIntervalTicks = 40;

	/** Клітини далі за цю відстань від гравця клієнту не надсилаються. */
	public int syncRadius = 1500;

	public static RealWeatherConfig get() {
		return instance;
	}

	public static void load() {
		Path path = FabricLoader.getInstance().getConfigDir().resolve("realweather.json");
		if (Files.exists(path)) {
			try (Reader reader = Files.newBufferedReader(path)) {
				RealWeatherConfig loaded = GSON.fromJson(reader, RealWeatherConfig.class);
				if (loaded != null) {
					instance = loaded;
				}
			} catch (Exception e) {
				RealWeatherMod.LOGGER.warn("Не вдалося прочитати realweather.json, беру значення за замовчуванням", e);
			}
		}
		instance.sanitize();
		// Перезаписуємо файл, щоб у ньому з'явилися нові поля та виправлені значення.
		try (Writer writer = Files.newBufferedWriter(path)) {
			GSON.toJson(instance, writer);
		} catch (IOException e) {
			RealWeatherMod.LOGGER.warn("Не вдалося зберегти realweather.json", e);
		}
	}

	private void sanitize() {
		maxCells = clamp(maxCells, 1, 128);
		spawnIntervalTicks = clamp(spawnIntervalTicks, 20, 1_000_000);
		minRadius = clamp(minRadius, 30, 2000);
		maxRadius = clamp(maxRadius, minRadius, 4000);
		minLifetimeTicks = clamp(minLifetimeTicks, 200, 1_000_000);
		maxLifetimeTicks = clamp(maxLifetimeTicks, minLifetimeTicks, 2_000_000);
		windSpeed = Math.max(0.0, Math.min(2.0, windSpeed));
		minIntensity = Math.max(0.05, Math.min(1.0, minIntensity));
		maxIntensity = Math.max(minIntensity, Math.min(1.0, maxIntensity));
		syncIntervalTicks = clamp(syncIntervalTicks, 5, 400);
		syncRadius = clamp(syncRadius, 200, 10_000);
	}

	private static int clamp(int value, int min, int max) {
		return Math.max(min, Math.min(max, value));
	}
}

package com.realweather.client;

import com.realweather.storm.StormCell;

import java.util.List;

/**
 * Клієнтська копія клітин. Між пакетами сервера клітини рухаються за власною швидкістю,
 * тому дощ змінюється плавно, а не стрибками раз на пару секунд.
 */
public final class ClientStormData {
	private static volatile List<StormCell> cells = List.of();
	private static volatile int syncTick = 0;
	private static volatile boolean active = false;
	private static int clientTick = 0;

	private ClientStormData() {
	}

	public static void onSync(List<StormCell> newCells) {
		cells = List.copyOf(newCells);
		syncTick = clientTick;
		active = true;
	}

	public static void tick() {
		clientTick++;
	}

	public static void reset() {
		cells = List.of();
		active = false;
	}

	/** Чи отримував клієнт дані від сервера (інакше лишається ванільна погода). */
	public static boolean isActive() {
		return active;
	}

	/** Місцева сила дощу (0..1) у точці. Клітини об'єднуються так, щоб сума не перевищувала 1. */
	public static float rainAt(double x, double z, float partialTick) {
		float extra = (clientTick - syncTick) + partialTick;
		float dry = 1f;
		for (StormCell cell : cells) {
			dry *= 1f - cell.intensityAt(x, z, extra);
		}
		return 1f - dry;
	}
}

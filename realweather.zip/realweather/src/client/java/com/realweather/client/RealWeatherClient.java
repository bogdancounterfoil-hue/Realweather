package com.realweather.client;

import com.realweather.network.StormSyncPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class RealWeatherClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ClientPlayNetworking.registerGlobalReceiver(StormSyncPayload.TYPE, (payload, context) ->
				// Пакет приходить у потоці клієнта, тому можна одразу оновлювати дані.
				ClientStormData.onSync(payload.cells()));

		ClientTickEvents.END_CLIENT_TICK.register(client -> ClientStormData.tick());

		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientStormData.reset());
	}
}

package com.realweather.client.mixin;

import com.realweather.client.ClientStormData;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Підміняє «рівень дощу» на клієнті: замість глобального значення повертає місцеве
 * для позиції камери. Від цього значення залежать і малювання дощу, і звук, і темрява неба.
 */
@Mixin(Level.class)
public abstract class LevelMixin {
	@Inject(method = "getRainLevel", at = @At("HEAD"), cancellable = true)
	private void realweather$localRain(float partialTick, CallbackInfoReturnable<Float> cir) {
		Level self = (Level) (Object) this;
		if (!self.isClientSide() || !ClientStormData.isActive() || self.dimension() != Level.OVERWORLD) {
			return;
		}
		Entity camera = Minecraft.getInstance().getCameraEntity();
		if (camera == null) {
			return;
		}
		cir.setReturnValue(ClientStormData.rainAt(camera.getX(), camera.getZ(), partialTick));
	}
}
